package com.groupama.pasrau.batch.job;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import com.groupama.pasrau.batch.job.step.beneficiaire.BeneficiaireAnonymisationStepReader;
import com.groupama.pasrau.batch.metier.AnonymisationRepositoryCustom;
import com.groupama.pasrau.batch.model.BeneficiaireAAnonymiser;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.StepSynchronizationManager;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.test.MetaDataInstanceFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class IndividuAnonymisationStepReaderTest {

    @Autowired
    private ApplicationContext context;

    @MockBean
    private AnonymisationRepositoryCustom anonymisationRepositoryCustom;

    @Test
    public void reader_should_read_items_from_repository() throws Exception {

        // GIVEN
        JobExecution jobExecution = MetaDataInstanceFactory.createJobExecution();
        ExecutionContext ec = jobExecution.getExecutionContext();

        ec.putInt("MOIS_RET_DT_CREATION", 12);
        ec.putInt("MOIS_RET_DT_VERSEMENT", 24);
        ec.putInt("MOIS_RET_DT_DECLARATION", 36);
        ec.putInt("MOIS_RET_DT_REGULARISATION", 48);

        StepExecution stepExecution = jobExecution.createStepExecution("step");
        StepSynchronizationManager.register(stepExecution);

        List<BeneficiaireAAnonymiser> data = Arrays.asList(
            new BeneficiaireAAnonymiser(1L, "123"),
            new BeneficiaireAAnonymiser(2L, "456")
        );

        when(anonymisationRepositoryCustom.extractBeneficiaireAAnonymis(
            12, 48, 24, 36)).thenReturn(data);

        BeneficiaireAnonymisationStepReader reader = context.getBean(
            BeneficiaireAnonymisationStepReader.class);



        StepSynchronizationManager.close();
    }
}
