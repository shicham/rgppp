package com.groupama.pasrau.batch;
import com.groupama.pasrau.batch.metier.ParametreRepository;
import com.groupama.pasrau.batch.model.Parameter;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.mockito.Mockito.when;
import static org.junit.Assert.assertEquals;
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = RgpdApplication.class)
@TestPropertySource({
    "classpath:applicationRgpd.properties",
    "classpath:spring-datasource.properties"
})
public class RgpdApplicationTest {

    @MockBean
    private ParametreRepository parametreRepository;

    @Test
    public void testRgpdParametersMock() {
        // Mock des paramètres RGPD obligatoires
        when(parametreRepository.findByTypeAndSousType("JOB", "JOB-RGPD"))
            .thenReturn(buildRgpdParameters());

        // Récupération des paramètres via le repo mocké
        List<Parameter> parameters = parametreRepository.findByTypeAndSousType("JOB", "JOB-RGPD");

        // Vérifications simples
        assertEquals(4, parameters.size());
        assertEquals("36", parameters.stream()
            .filter(p -> p.getCode().equals("MOIS_RET_DT_CREATION"))
            .findFirst().get().getValeur()
        );
    }

    private List<Parameter> buildRgpdParameters() {
        return Arrays.asList(
            param("MOIS_RET_DT_CREATION", "36"),
            param("MOIS_RET_DT_VERSEMENT", "36"),
            param("MOIS_RET_DT_DECLARATION", "36"),
            param("MOIS_RET_DT_REGULARISATION", "36")
        );
    }

    private Parameter param(String code, String valeur) {
        Parameter p = new Parameter();
        p.setType("JOB");
        p.setSousType("JOB-RGPD");
        p.setCode(code);
        p.setValeur(valeur);
        return p;
    }
}
