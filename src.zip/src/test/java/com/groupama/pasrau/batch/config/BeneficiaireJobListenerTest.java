package com.groupama.pasrau.batch.config;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import com.groupama.pasrau.batch.listener.BeneficiaireJobListener;
import com.groupama.pasrau.batch.metier.ParametreRepository;
import com.groupama.pasrau.batch.model.Parameter;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.test.MetaDataInstanceFactory;
import org.springframework.test.context.TestPropertySource;

@RunWith(MockitoJUnitRunner.class)
@TestPropertySource({
    "classpath:applicationRgpd.properties",
    "classpath:spring-datasource.properties",
    "job.beneficiaire.name=beneficiaireJob",
    "step.beneficiaire.name=beneficiaireAnonymisationStep"
})
public class BeneficiaireJobListenerTest {

    @InjectMocks
    private BeneficiaireJobListener listener;

    @Mock
    private ParametreRepository parametreRepository;

    @Test
    public void beforeJob_should_put_parameters_in_execution_context() {

        // GIVEN
        JobExecution jobExecution = MetaDataInstanceFactory.createJobExecution();

        List<Parameter> params = Arrays.asList(
            param("MOIS_RET_DT_CREATION", "12"),
            param("MOIS_RET_DT_VERSEMENT", "24"),
            param("MOIS_RET_DT_DECLARATION", "36"),
            param("MOIS_RET_DT_REGULARISATION", "48")
        );



    }

    @Test(expected = IllegalStateException.class)
    public void beforeJob_should_fail_if_param_missing() {

        JobExecution jobExecution = MetaDataInstanceFactory.createJobExecution();

        when(parametreRepository.findByTypeAndSousType("JOB", "JOB-RGPD"))
            .thenReturn(Arrays.asList(
                param("MOIS_RET_DT_CREATION", "12")
            ));

        listener.beforeJob(jobExecution);
    }

    private Parameter param(String code, String value) {
        Parameter p = new Parameter();
        p.setCode(code);
        p.setValeur(value);
        return p;
    }
}
