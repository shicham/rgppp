package com.groupama.pasrau.batch.job;

import static org.mockito.Mockito.verify;

import com.groupama.pasrau.batch.job.step.beneficiaire.BeneficiaireAnonymisationStepWriter;
import com.groupama.pasrau.batch.metier.AnonymisationRepositoryCustom;
import com.groupama.pasrau.batch.model.BeneficiaireAAnonymiser;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.context.TestPropertySource;

@RunWith(MockitoJUnitRunner.class)
@TestPropertySource({
    "classpath:applicationRgpd.properties",
    "classpath:spring-datasource.properties"
})
public class BeneficiaireAnonymisationStepWriterTest {

    @InjectMocks
    private BeneficiaireAnonymisationStepWriter writer;

    @Mock
    private AnonymisationRepositoryCustom anonymisationRepositoryCustom;

    @Test
    public void writer_should_anonymise_beneficiaires() {

        // GIVEN
        List<BeneficiaireAAnonymiser> items = Arrays.asList(
            new BeneficiaireAAnonymiser(1L, "nir1"),
            new BeneficiaireAAnonymiser(2L, "nir2")
        );


        }
}

