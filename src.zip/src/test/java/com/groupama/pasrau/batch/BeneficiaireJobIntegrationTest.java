package com.groupama.pasrau.batch;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

import com.groupama.pasrau.batch.metier.AnonymisationRepositoryCustom;
import com.groupama.pasrau.batch.metier.ParametreRepository;
import com.groupama.pasrau.batch.model.Parameter;
import java.util.Arrays;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@TestPropertySource({
    "classpath:applicationRgpd.properties",
    "classpath:spring-datasource.properties"
})
@SpringBootTest(classes = RgpdApplication.class)
public class BeneficiaireJobIntegrationTest {

    @Autowired
    private JobLauncher jobLauncher;

    @Autowired
    private Job beneficiaireJob;

    @MockBean
    private ParametreRepository parametreRepository;

    @MockBean
    private AnonymisationRepositoryCustom anonymisationRepositoryCustom;

    @Test
    public void job_should_complete() throws Exception {

        when(parametreRepository.findByTypeAndSousType("JOB", "JOB-RGPD"))
            .thenReturn(Arrays.asList(
                param("MOIS_RET_DT_CREATION", "12"),
                param("MOIS_RET_DT_VERSEMENT", "24"),
                param("MOIS_RET_DT_DECLARATION", "36"),
                param("MOIS_RET_DT_REGULARISATION", "48")
            ));

        when(anonymisationRepositoryCustom.extractBeneficiaireAAnonymis(
            anyInt(), anyInt(), anyInt(), anyInt()))
            .thenReturn(Arrays.asList());

    }

    private Parameter param(String code, String value) {
        Parameter p = new Parameter();
        p.setCode(code);
        p.setValeur(value);
        return p;
    }
}

