
INSERT INTO PARAMETER (TYPE, SOUS_TYPE, CODE, VALEUR) VALUES
                                                          ('JOB', 'JOB-RGPD', 'MOIS_RET_DT_CREATION', '36'),
                                                          ('JOB', 'JOB-RGPD', 'MOIS_RET_DT_VERSEMENT', '36'),
                                                          ('JOB', 'JOB-RGPD', 'MOIS_RET_DT_DECLARATION', '36'),
                                                          ('JOB', 'JOB-RGPD', 'MOIS_RET_DT_REGULARISATION', '36');
