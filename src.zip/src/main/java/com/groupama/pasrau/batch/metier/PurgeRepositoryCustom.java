package com.groupama.pasrau.batch.metier;

import com.groupama.pasrau.batch.model.BeneficiaireAAnonymiser;
import com.groupama.pasrau.model.entities.LienBenefDeclaration;
import java.util.List;

public interface PurgeRepositoryCustom {

    /* ===============================
       1️⃣ Tables de liaison
       =============================== */

    int deleteLienRegulBenefDeclarationByBeneficiaireIds(List<Long> beneficiaireIds);

    int deleteLienBenefDeclarationByBeneficiaireIds(List<Long> beneficiaireIds);

    int deleteLienVersementDeclarationByBeneficiaireIds(List<Long> beneficiaireIds);

    int deleteLienRegulVersDeclarationByBeneficiaireIds(List<Long> beneficiaireIds);


    /* ===============================
       2️⃣ Contribution sociale
       =============================== */

    int deleteContributionSocialeRegulBeneficiaireByBeneficiaireIds(List<Long> beneficiaireIds);
    int deleteContributionSocialeRegulVersementByBeneficiaireIds(List<Long> beneficiaireIds);
    int deleteContributionSocialeVersementByBeneficiaireIds(List<Long> beneficiaireIds);
    List<LienBenefDeclaration> lienBenefDeclarationByBeneficiaireIds(List<Long> beneficiaireIds);
    /* ===============================
       3️⃣ Historiques bénéficiaire
       =============================== */

    int deleteHistoTauxBeneficiaireByBeneficiaireIds(List<Long> beneficiaireIds);

    int deleteHistoBeneficiaireByBeneficiaireIds(List<Long> beneficiaireIds);

    int deleteDeclarationAmorcageTauxByBeneficiaireIds(List<Long> beneficiaireIds);

    /* ===============================
       4️⃣ Versements
       =============================== */
    int deleteDeclaration(List<Long> beneficiaireIds);
    int deleteDeclarationByIds(List<Long> ids);
    /* ===============================
       4️⃣ Versements
       =============================== */

    int deleteRegularisationVersementByBeneficiaireIds(List<Long> beneficiaireIds);

    int deleteVersementByBeneficiaireIds(List<Long> beneficiaireIds);


    /* ===============================
       5️⃣ Régularisation bénéficiaire
       =============================== */

    int deleteRegularisationBeneficiaireByBeneficiaireIds(List<Long> beneficiaireIds);


    /* ===============================
       6️⃣ Historiques individu
       =============================== */

    int deleteHistoTauxIndividu();

    int deleteHistoDonneesIndividu();


    /* ===============================
       7️⃣ Individu (non partagé)
       =============================== */

    int deleteIndividu();


    /* ===============================
       8️⃣ Suppression finale
       =============================== */

    int deleteBeneficiaireByIds(List<Long> beneficiaireIds);


    List<BeneficiaireAAnonymiser> extractBeneficiaireAnonymiser(Integer moisAnonymisation);

}
