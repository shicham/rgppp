package com.groupama.pasrau.batch.metier;

import com.groupama.pasrau.batch.model.Parameter;
import java.util.List;
import java.util.Optional;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ParametreRepository extends CrudRepository<Parameter, String> {
    Optional<Parameter> findByCode(String code);
    List<Parameter> findByType(String type);
    List<Parameter> findByTypeAndSousType(String type, String soustype);
}
