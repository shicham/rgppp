package com.groupama.pasrau.batch;

import com.groupama.pasrau.batch.commun.BatchConstantes;
import com.groupama.pasrau.batch.config.ApplicationRgpdConfig;
import com.groupama.spares.core.Spares;
import com.groupama.spares.core.log.SupportedLoggingImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.PropertySource;

import java.time.LocalDateTime;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * @author GSE0932
 */

@SpringBootApplication
@EnableBatchProcessing
@EnableAutoConfiguration
@PropertySource("classpath:applicationRgpd.properties")
@EnableJpaRepositories(basePackages = "com.groupama.pasrau")
@EntityScan(basePackages = "com.groupama.pasrau")
public class RgpdApplication {

    /**
     * The Constant LOGGER.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(RgpdApplication.class);

    public static void main(String[] args) throws Exception {

        if (args.length == 0) {
            LOGGER.error("Aucun nom de job fourni en paramètre.");
            System.exit(BatchConstantes.JobConstantes.CODE_RETOUR_ERREUR);
        }
        try {
            String jobName = args[0];
            ApplicationRgpdConfig.setJobName(jobName);
            Spares.configurator().withExternalLoggingImpl(SupportedLoggingImpl.SLF4J);

            LOGGER.debug("Configuration du contexte de l'application");
            // Configuration du contexte de l'application
            final ConfigurableApplicationContext ctx = new SpringApplicationBuilder(
                RgpdApplication.class)
                .web(WebApplicationType.NONE)
                .properties("spring.config.name:applicationRgpd,spring-datasource")
                .build()
                .run(args);

            // Construction des paramètres du job --> date d'execution du job
            LOGGER.debug("Construction des paramètres du job --> Date d'execution du job");
            final JobParametersBuilder jobBuilder = new JobParametersBuilder();
            jobBuilder.addString(BatchConstantes.JobConstantes.DATE_EXECUTION_FORMAT_KEY,
                BatchConstantes.DatesConstantes.PATTERN_DATE_YYYYMMDD_HHMMSS.format(LocalDateTime.now()));

            // lancement du job principal du batch
            LOGGER.debug("Lancement du job principal du batch");
            final JobLauncher jobLauncher = ctx.getBean(JobLauncher.class);
            final Job pasrauRgpdJob = (Job) ctx.getBean(jobName);
            final JobExecution result = jobLauncher.run(pasrauRgpdJob,  jobBuilder.toJobParameters());

            // Gestion du cas d'erreur générique si le batch ne s'est pas terminé correctement
            if (!ExitStatus.COMPLETED.equals(result.getExitStatus())) {
                System.exit(BatchConstantes.JobConstantes.CODE_RETOUR_ERREUR);
            }

            System.exit(BatchConstantes.JobConstantes.CODE_RETOUR_OK);
        } catch (Exception e) {
            LOGGER.error("Erreur fatale lors de l'exécution du batch RGPD", e);
            System.exit(BatchConstantes.JobConstantes.CODE_RETOUR_ERREUR);
        }
    }
}
