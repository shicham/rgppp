package com.groupama.pasrau.batch.job.step.individu;

import com.groupama.pasrau.batch.model.BeneficiaireAAnonymiser;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class IndividuAnonymisationStepConfig {

    /**
     * Configuration du step d'anonymisation des individus.
     *
     * @param stepBuilderFactory le factory pour construire le step
     * @param individuAnonymisationStepReader le reader pour lire les individus à anonymiser
     * @param individuAnonymisationStepWriter le writer pour écrire les individus anonymisés
     * @param individuStepListener le listener pour suivre l'exécution du step
     * @return le step d'anonymisation des individus
     */
    @Bean
    public Step individuAnonymisationStep(
        StepBuilderFactory stepBuilderFactory,
        ItemReader<BeneficiaireAAnonymiser> individuAnonymisationStepReader,
        ItemWriter<BeneficiaireAAnonymiser> individuAnonymisationStepWriter,
        StepExecutionListener individuStepListener) {

        return stepBuilderFactory.get("individuAnonymisationStep")
            .<BeneficiaireAAnonymiser, BeneficiaireAAnonymiser>chunk(1000)
            .reader(individuAnonymisationStepReader)
            .writer(individuAnonymisationStepWriter)
            .listener(individuStepListener)
            .build();
    }
}

