package com.groupama.pasrau.batch.job.step.purge;

import com.groupama.pasrau.batch.commun.utils.FileLineUtils;
import com.groupama.pasrau.batch.config.ApplicationRgpdConfig;
import com.groupama.pasrau.batch.utils.JobConstants;
import com.groupama.pasrau.batch.metier.PurgeRepositoryCustom;
import com.groupama.pasrau.batch.model.BeneficiaireAAnonymiser;
import java.io.File;
import java.time.LocalDateTime;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.support.ListItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@StepScope
public class PurgeStepReader implements ItemReader<BeneficiaireAAnonymiser> {

    private static final Logger log =  LoggerFactory.getLogger(PurgeStepReader.class);

    private ListItemReader<BeneficiaireAAnonymiser> delegate;

    private final PurgeRepositoryCustom purgeRepositoryCustom;

    @Autowired
    private ApplicationRgpdConfig applicationRgpdConfig;

    @Value("#{jobExecutionContext['" + JobConstants.DATE_ANONYMISATION_KEY + "']}")
    private LocalDateTime dateAnonimisation;

    @Value("#{jobExecutionContext['" + JobConstants.I_DATE_EXECUTION_JOB + "']}")
    private LocalDateTime dateExecutionJob;

    @Value("#{jobExecutionContext['" + JobConstants.MOIS_RET_DT_ANONYMISATION + "']}")
    private Integer moisAnonymisation;

    public PurgeStepReader(PurgeRepositoryCustom purgeRepositoryCustom) {
        this.purgeRepositoryCustom = purgeRepositoryCustom;
    }

    @Override
    public BeneficiaireAAnonymiser read() {
        if (delegate == null) {
            delegate = loadData();
        }
        return delegate.read();
    }

    /** Charge les données à partir de la source de données (par exemple, une base de données) et les prépare pour la lecture.
     *
     * @return un ListItemReader contenant les éléments à lire
     */
    private ListItemReader<BeneficiaireAAnonymiser> loadData() {
        log.info("✔ {} moisAnonymisation", moisAnonymisation);
        List<BeneficiaireAAnonymiser> items = purgeRepositoryCustom.extractBeneficiaireAnonymiser(moisAnonymisation);

        log.info("✔ {} bénéficiaires a purger", items.size());

        String lCompteRenduTechnique = applicationRgpdConfig.getCheminFichierOutputCompteRenduTechnique(dateExecutionJob);
        FileLineUtils.processLine(new File(lCompteRenduTechnique), "bénéficiaires à purger à traiter : " + items.size(), true);
        log.debug("Fin du Traitement de read {}", LocalDateTime.now());

        return new ListItemReader<>(items);
    }
}

