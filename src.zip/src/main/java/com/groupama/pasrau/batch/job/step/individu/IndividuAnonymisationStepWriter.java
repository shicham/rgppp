package com.groupama.pasrau.batch.job.step.individu;

import com.groupama.pasrau.batch.commun.utils.FileLineUtils;
import com.groupama.pasrau.batch.config.ApplicationRgpdConfig;
import com.groupama.pasrau.batch.utils.JobConstants;
import com.groupama.pasrau.batch.metier.AnonymisationRepositoryCustom;
import com.groupama.pasrau.batch.model.BeneficiaireAAnonymiser;
import java.io.File;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@StepScope
public class IndividuAnonymisationStepWriter implements ItemWriter<BeneficiaireAAnonymiser> {

    private static final Logger log = LoggerFactory.getLogger(IndividuAnonymisationStepWriter.class);


    @Autowired
    private AnonymisationRepositoryCustom anonymisationRepositoryCustom;

    @Autowired
    private ApplicationRgpdConfig applicationRgpdConfig;

    @Value("#{jobExecutionContext['" + JobConstants.DATE_ANONYMISATION_KEY + "']}")
    private LocalDateTime dateAnonimisation;

    @Value("#{jobExecutionContext['" + JobConstants.I_DATE_EXECUTION_JOB + "']}")
    private LocalDateTime dateExecutionJob;

   /**  * Ce writer est responsable de l'anonymisation des individus liés aux bénéficiaires éligibles.
     * Il effectue les étapes suivantes :
     * 1. Récupère les IDs des bénéficiaires à anonymiser.
     * 2. Récupère les NIR associés à ces bénéficiaires.
     * 3. Filtre les NIR pour identifier ceux qui sont éligibles à l'anonymisation.
     * 4. Anonymise les individus liés aux NIR éligibles.
     * 5. Anonymise les bénéficiaires en fonction de leurs IDs.
     *
     * @param items la liste des bénéficiaires à anonymiser
     */
    @Override
    public void write(List<? extends BeneficiaireAAnonymiser> items) {
        if (items == null || items.isEmpty()) {
            return;
        }
        List<Long> ids = items.stream()
            .map(BeneficiaireAAnonymiser::getIdBeneficiaire)
            .collect(Collectors.toList());

        List<String> nir = items.stream()
            .filter(e -> StringUtils.isNoneBlank(e.getNir()))
            .map(BeneficiaireAAnonymiser::getNir)
            .collect(Collectors.toList());

        if (nir != null && !nir.isEmpty()) {
            List<String> nirs = anonymisationRepositoryCustom.findNirElegible(nir);
            Set<String> nirsSet = new HashSet<>(nirs);
            List<String> filteredNir = nir.stream()
                .filter(n -> !nirsSet.contains(n))
                .collect(Collectors.toList());

            if (filteredNir != null && !filteredNir.isEmpty()) {
                List<Long> individuIds = anonymisationRepositoryCustom.findIndividuRgpdNyNir(
                    filteredNir);
                if (individuIds != null && !individuIds.isEmpty()) {
                    int countHistoDonneeIndiv = anonymisationRepositoryCustom.anonymisationHistoDonneesIndividu(individuIds);
                    int countIndiv = anonymisationRepositoryCustom.anonymisationIndividu(individuIds);
                    log.info("         |_______✔ {} Individu anonymisés", countIndiv);
                    log.info("             |_______✔ {} histoDonneesIndividu anonymisés", countHistoDonneeIndiv);
                    writeTechnicalReport(individuIds,countIndiv,countHistoDonneeIndiv);
                }
            }
        }
        anonymisationRepositoryCustom.anonymiserBenefeciareNir(ids);


    }

   /** Écrit un compte rendu technique dans un fichier de log avec les détails de l'anonymisation des individus.
     *
     * @param individuIds        la liste des IDs des individus anonymisés
     * @param countIndiv         le nombre d'individus anonymisés
     * @param countHistoDonneeIndiv le nombre d'historique données individu anonymisés
     */
    private void writeTechnicalReport(List<Long> individuIds, int countIndiv, int countHistoDonneeIndiv) {
        try {
            String filePath = applicationRgpdConfig.getCheminFichierOutputCompteRenduTechnique(dateExecutionJob);
            File file = new File(filePath);
            FileLineUtils.processLine(file,String.format("         |_______✔  Individu anonymisés ids: %s",individuIds), true);
            FileLineUtils.processLine(file,String.format("         |_______✔  Individu anonymisés : {%s}",countIndiv), true);
            FileLineUtils.processLine(file, String.format("             |_______✔  histoDonneesIndividu anonymisés : {%s}",countHistoDonneeIndiv), true);
        } catch (Exception e) {
            log.error("Erreur lors de l’écriture du compte rendu technique", e);
        }
    }
}
