package com.groupama.pasrau.batch.job.step.beneficiaire;

import com.groupama.pasrau.batch.commun.utils.FileLineUtils;
import com.groupama.pasrau.batch.config.ApplicationRgpdConfig;
import com.groupama.pasrau.batch.utils.JobConstants;
import com.groupama.pasrau.batch.metier.AnonymisationRepositoryCustom;
import com.groupama.pasrau.batch.model.BeneficiaireAAnonymiser;
import java.io.File;
import java.time.LocalDateTime;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.support.ListItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@StepScope
public class BeneficiaireAnonymisationStepReader implements ItemReader<BeneficiaireAAnonymiser> {

    private static final Logger log =  LoggerFactory.getLogger(BeneficiaireAnonymisationStepReader.class);

    @Autowired
    private AnonymisationRepositoryCustom anonymisationRepositoryCustom;
    @Autowired
    private ApplicationRgpdConfig applicationRgpdConfig;

    private ListItemReader<BeneficiaireAAnonymiser> delegate;

    @Value("#{jobExecutionContext['" + JobConstants.MOIS_RET_DT_CREATION + "']}")
    private Integer moisRetentionCreation;

    @Value("#{jobExecutionContext['" + JobConstants.MOIS_RET_DT_VERSEMENT + "']}")
    private Integer moisRetentionVersement;

    @Value("#{jobExecutionContext['" + JobConstants.MOIS_RET_DT_DECLARATION + "']}")
    private Integer moisRetentionDeclaration;

    @Value("#{jobExecutionContext['" + JobConstants.MOIS_RET_DT_REGULARISATION + "']}")
    private Integer moisRetentionRegularisation;

    @Value("#{jobExecutionContext['" + JobConstants.DATE_ANONYMISATION_KEY + "']}")
    private LocalDateTime dateAnonimisation;

    private StepExecution stepExecution;

    @Value("#{jobExecutionContext['" + JobConstants.I_DATE_EXECUTION_JOB + "']}")
    private LocalDateTime dateExecutionJob;



    @BeforeStep
    public void saveStepExecution(StepExecution stepExecution) {
        this.stepExecution = stepExecution;
    }

    @Override
    public BeneficiaireAAnonymiser read() {
        if (delegate == null) {
            delegate = loadData();
        }
        return delegate.read();
    }
 /** * Charge les données des bénéficiaires à anonymiser en fonction des critères de rétention.
     * Les critères de rétention sont basés sur les mois de création, versement, déclaration et régularisation.
     * Les bénéficiaires éligibles sont extraits de la base de données via le repository personnalisé.
     * Un rapport technique est également généré pour documenter le nombre de bénéficiaires à traiter.
     *
     * @return un ListItemReader contenant la liste des bénéficiaires à anonymiser
     */
    private ListItemReader<BeneficiaireAAnonymiser> loadData() {
     List<BeneficiaireAAnonymiser> items = anonymisationRepositoryCustom.extractBeneficiaireAAnonymis(moisRetentionCreation, moisRetentionRegularisation, moisRetentionVersement, moisRetentionDeclaration);
        log.info("✔ {} bénéficiaires éligibles à l’anonymisation", items.size());
        String lCompteRenduTechnique = applicationRgpdConfig.getCheminFichierOutputCompteRenduTechnique(dateExecutionJob);
        FileLineUtils.processLine(new File(lCompteRenduTechnique), String.format("Date anonymisation : %s " , dateAnonimisation), true);
        FileLineUtils.processLine(new File(lCompteRenduTechnique), String.format("nombre de bénéficiaires à traiter : %s" , items.size()), true);
        log.debug("Fin du Traitement de read {}", LocalDateTime.now());
        return new ListItemReader<>(items);
    }
}

