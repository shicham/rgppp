package com.groupama.pasrau.batch.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RgpdJobConfiguration {

    /**
     * Configuration du job d'anonymisation des bénéficiaires et des individus associés.
     * Ce job comprend deux étapes : l'anonymisation des bénéficiaires et l'anonymisation des individus.
     * Un listener est associé pour suivre l'exécution du job.
     *
     * @param jobBuilderFactory le factory pour construire le job
     * @param beneficiaireAnonymisationStep l'étape d'anonymisation des bénéficiaires
     * @param individuAnonymisationStep l'étape d'anonymisation des individus
     * @param beneficiaireJobListener le listener pour suivre l'exécution du job
     * @return le job d'anonymisation configuré
     */
    @Bean
    public Job beneficiaireJob(
        JobBuilderFactory jobBuilderFactory, Step beneficiaireAnonymisationStep, Step individuAnonymisationStep, JobExecutionListener beneficiaireJobListener) {

        return jobBuilderFactory.get("beneficiaireJob")
            .incrementer(new RunIdIncrementer())
            .listener(beneficiaireJobListener)
            .start(beneficiaireAnonymisationStep)
            .next(individuAnonymisationStep) // nouveau step après la fin de l'anonymisation
            .build();
    }
/**
     * Configuration du job de purge des données anonymisées.
     * Ce job comprend une étape de purge et un listener pour suivre l'exécution du job.
     *
     * @param jobBuilderFactory le factory pour construire le job
     * @param purgeStep l'étape de purge des données anonymisées
     * @param purgeJobListener le listener pour suivre l'exécution du job
     * @return le job de purge configuré
     */
    @Bean
    public Job purgeJob(JobBuilderFactory jobBuilderFactory, Step purgeStep, JobExecutionListener purgeJobListener) {

        return jobBuilderFactory.get("purgeJob")
            .incrementer(new RunIdIncrementer())
            .listener(purgeJobListener)
            .start(purgeStep)
            .build();
    }
}
