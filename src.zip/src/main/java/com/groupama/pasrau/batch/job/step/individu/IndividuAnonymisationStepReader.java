package com.groupama.pasrau.batch.job.step.individu;

import com.groupama.pasrau.batch.utils.JobConstants;
import com.groupama.pasrau.batch.metier.AnonymisationRepositoryCustom;
import com.groupama.pasrau.batch.model.BeneficiaireAAnonymiser;
import com.groupama.pasrau.batch.model.BenfeciaireSharedData;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.support.ListItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@StepScope
public class IndividuAnonymisationStepReader implements ItemReader<BeneficiaireAAnonymiser> {

    private static final Logger log =  LoggerFactory.getLogger(IndividuAnonymisationStepReader.class);

    @Autowired
    private AnonymisationRepositoryCustom anonymisationRepositoryCustom;
    @Autowired
    BenfeciaireSharedData benfeciaireSharedData;
    private ListItemReader<BeneficiaireAAnonymiser> delegate;

    @Value("#{jobExecutionContext['" + JobConstants.DATE_ANONYMISATION_KEY + "']}")
    private LocalDateTime dateAnonimisation;



    @Override
    public BeneficiaireAAnonymiser read() {
        if (delegate == null) {
            delegate = loadData();
        }
        return delegate.read();
    }
    /** Charge les données à partir de la source de données (par exemple, une base de données) et les prépare pour la lecture.
     *
     * @return un ListItemReader contenant les éléments à lire
     */
    private ListItemReader<BeneficiaireAAnonymiser> loadData() {
       List<BeneficiaireAAnonymiser> items = new ArrayList<>(benfeciaireSharedData.getBeneficiaireIds());
        log.info("✔ {} Individu nirs éligibles à l’anonymisation", items.size());
        return new ListItemReader<>(items);
    }
}

