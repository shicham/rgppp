package com.groupama.pasrau.batch.config;

import com.groupama.pasrau.batch.commun.BatchConstantes;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties("application.config")
public class ApplicationRgpdConfig {

    public static String PATH_EEREUR="erreur/";
    public static String LOG_FILE="Logs/";
    private static String jobName;
    private String outputDir;
    private String archiveFile;
    private String erreurFichier;
    private String compteRendu;

    public static void setJobName(String jobName) {
        ApplicationRgpdConfig.jobName = jobName;
    }

    public String getOutputDir() {
        return outputDir;
    }

    public void setOutputDir(String outputDir) {
        this.outputDir = outputDir;
    }

    public String getArchiveFile() {
        return archiveFile;
    }

    public void setArchiveFile(String archiveFile) {
        this.archiveFile = archiveFile;
    }

    public String getErreurFichier() {
        return erreurFichier;
    }

    public void setErreurFichier(String erreurFichier) {
        this.erreurFichier = erreurFichier;
    }

    public String getCheminFichierOutputErreur(){

        return Paths.get(getOutputDir(),PATH_EEREUR).toString();
    }

    public String getCompteRendu() { return compteRendu;
    }
    public void setCompteRendu(String compteRendu) { this.compteRendu = compteRendu;
    }

    public ApplicationRgpdConfig() {
    }
    /**
     * generer le fichier de compte de rendu d'execution
     * @param pLocalDateTime pLocalDateTime
     * @return
     */
    public String getCheminFichierOutputCompteRenduTechnique(final LocalDateTime pLocalDateTime) {

        String lAnnee = BatchConstantes.DatesConstantes.PATTERN_DATE_YYYY.format(pLocalDateTime);
        String lDateYYYYMMDDHHMMSS = BatchConstantes.DatesConstantes.PATTERN_DATE_YYYYMMDD_HHMMSS.format(pLocalDateTime);

        return String.format("%s%s%s%s%s%s", getOutputDir(), BatchConstantes.FichierConstantes.PATH_COMPTE_RENDU,
            BatchConstantes.FichierConstantes.FILE_SEPARATEUR, lAnnee, BatchConstantes.FichierConstantes.FILE_SEPARATEUR,
            MessageFormat.format("{0}-{1}.txt", jobName, lDateYYYYMMDDHHMMSS));
    }
}
