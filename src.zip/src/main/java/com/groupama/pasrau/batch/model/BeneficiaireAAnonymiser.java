package com.groupama.pasrau.batch.model;

public class BeneficiaireAAnonymiser {

    private final Long idBeneficiaire;
    private final String nir;

    public BeneficiaireAAnonymiser(Long idBeneficiaire, String nir) {
        this.idBeneficiaire = idBeneficiaire;
        this.nir = nir;
    }

    public Long getIdBeneficiaire() {
        return idBeneficiaire;
    }

    public String getNir() {
        return nir;
    }
}
