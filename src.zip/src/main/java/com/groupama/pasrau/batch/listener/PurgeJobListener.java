package com.groupama.pasrau.batch.listener;

import com.groupama.pasrau.batch.commun.BatchConstantes;
import com.groupama.pasrau.batch.commun.BatchConstantes.DatesConstantes;
import com.groupama.pasrau.batch.utils.JobConstants;
import com.groupama.pasrau.batch.metier.ParametreRepository;
import com.groupama.pasrau.batch.model.Parameter;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.stereotype.Component;

@Component
public class PurgeJobListener implements JobExecutionListener {

    private static final Logger log = LoggerFactory.getLogger(PurgeJobListener.class);
    private final ParametreRepository parametreRepository;

    public PurgeJobListener(ParametreRepository parametreRepository) {
        this.parametreRepository = parametreRepository;
    }

    @Override
    public void beforeJob(JobExecution jobExecution) {
        log.info("▶ Job started");
        Map<String, Integer> retentionParams = parametreRepository
            .findByTypeAndSousType("JOB", "JOB-PURGE")
            .stream()
            .collect(Collectors.toMap(
                Parameter::getCode,
                p -> Integer.valueOf(p.getValeur())
            ));

        put(jobExecution, JobConstants.MOIS_RET_DT_ANONYMISATION, retentionParams);

        String dateExecutionJob = jobExecution.getJobParameters().getString(BatchConstantes.JobConstantes.DATE_EXECUTION_FORMAT_KEY);
        LocalDateTime lDateTime =  LocalDateTime.parse(dateExecutionJob, DatesConstantes.PATTERN_DATE_YYYYMMDD_HHMMSS);
        jobExecution.getExecutionContext().put(JobConstants.I_DATE_EXECUTION_JOB, lDateTime);


    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        log.info("✔ Job finished with status {}", jobExecution.getStatus());
    }

   /** Récupère la valeur du paramètre à partir de la map et la stocke dans le contexte d'exécution du job.
     *
     * @param jobExecution l'exécution du job
     * @param key la clé du paramètre à récupérer
     * @param map la map contenant les paramètres
     */
    private void put(JobExecution jobExecution, String key, Map<String, Integer> map) {
        Integer value = map.get(key);
        if (value == null) {
            throw new IllegalStateException("Paramètre obligatoire manquant : " + key);
        }
        jobExecution.getExecutionContext().putInt(key, value);
    }

}
