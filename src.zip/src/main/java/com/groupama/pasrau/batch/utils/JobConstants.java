package com.groupama.pasrau.batch.utils;

public final class JobConstants {
    private JobConstants(){}
    private static final String MASK = "Xxxxx";
    public static final String MOIS_RET_DT_CREATION = "MOIS_RET_DT_CREATION";
    public static final String MOIS_RET_DT_VERSEMENT = "MOIS_RET_DT_VERSEMENT";
    public static final String MOIS_RET_DT_DECLARATION = "MOIS_RET_DT_DECLARATION";
    public static final String MOIS_RET_DT_REGULARISATION = "MOIS_RET_DT_REGULARISATION";
    public static final String MOIS_RET_DT_ANONYMISATION = "MOIS_RET_DT_ANONYMISATION";
    public static final String DATE_ANONYMISATION_KEY = "DATE_ANONYMISATION_KEY";
    public static final String I_DATE_EXECUTION_JOB ="dateExecutionJob";
}
