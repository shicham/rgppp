package com.groupama.pasrau.batch.metier;

import com.groupama.pasrau.batch.model.BeneficiaireAAnonymiser;
import java.time.LocalDateTime;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

@Repository
public class AnonymisationRepositoryCustomImpl implements AnonymisationRepositoryCustom {

    @PersistenceContext
    private EntityManager entityManager;


    @Override
    public List<BeneficiaireAAnonymiser> extractBeneficiaireAAnonymis(Integer moisRetentionCreation,
        Integer moisRetentionRegularisation, Integer moisRetentionVersement,
        Integer moisRetentionDeclaration) {
        return entityManager
            .createNativeQuery("SELECT " +
                "  B.ID AS idBeneficiaire, B.NIR AS nir " +
                "FROM BENEFICIAIRE B " +
                "LEFT JOIN ( " +
                "  SELECT N.ID_BENEFICIAIRE, MAX(A.DATE_ENVOI) AS DATE_ENVOI " +
                "  FROM LIEN_BENEF_DECLARATION N " +
                "  JOIN DECLARATION A ON N.ID_DECLARATION = A.ID " +
                "  GROUP BY N.ID_BENEFICIAIRE " +
                ") D ON B.ID = D.ID_BENEFICIAIRE " +
                "LEFT JOIN ( " +
                "  SELECT E.ID_BENEFICIAIRE, MAX(E.DATE_VERSEMENT) AS DATE_VERSEMENT " +
                "  FROM VERSEMENT E " +
                "  GROUP BY E.ID_BENEFICIAIRE " +
                ") C ON B.ID = C.ID_BENEFICIAIRE " +
                "LEFT JOIN ( " +
                "  SELECT V.ID_BENEFICIAIRE, MAX(RV.DATE_REGULARISATION) AS DATE_REGULARISATION " +
                "  FROM VERSEMENT V JOIN REGULARISATION_VERSEMENT RV ON V.ID = RV.ID_VERSEMENT " +
                "  GROUP BY V.ID_BENEFICIAIRE " +
                ") F ON B.ID = F.ID_BENEFICIAIRE " +
                "WHERE B.DATE_ANONYMISATION IS NULL AND (D.DATE_ENVOI <= ADD_MONTHS(SYSDATE, :moisRetentionDeclaration) OR D.DATE_ENVOI IS NULL) "
                +
                "AND B.DATE_CREATION < ADD_MONTHS(SYSDATE, :moisRetentionCreation) " +
                "AND (C.DATE_VERSEMENT <= ADD_MONTHS(SYSDATE, :moisRetentionVersement) OR C.DATE_VERSEMENT IS NULL) "
                +
                "AND (F.DATE_REGULARISATION <= ADD_MONTHS(SYSDATE, :moisRetentionRegularisation) OR F.DATE_REGULARISATION IS NULL)",
                "BeneficiaireAAnonymiserMapping")
            .setParameter("moisRetentionCreation", moisRetentionCreation)
            .setParameter("moisRetentionVersement", moisRetentionVersement)
            .setParameter("moisRetentionRegularisation", moisRetentionRegularisation)
            .setParameter("moisRetentionDeclaration", moisRetentionDeclaration)
            .getResultList();
    }


    @Override
    public List<BeneficiaireAAnonymiser> findBenefAnonymise(LocalDateTime  dateAnonym) {
        LocalDateTime startOfDay = dateAnonym.minusSeconds(10l);
        LocalDateTime endOfDay = dateAnonym.plusSeconds(3l);

        return entityManager
            .createNativeQuery(
                "select ID AS idBeneficiaire, NIR AS nir from Beneficiaire where  "
                    + "  date_anonymisation >= :startOfDay and  date_anonymisation < :endOfDay ",
                "BeneficiaireAAnonymiserMapping" )
            .setParameter("startOfDay", startOfDay)
            .setParameter("endOfDay", endOfDay)
            .getResultList();
    }


    @Override
    public List<String> findNirElegible(List<String> nirs) {
        return entityManager
            .createNativeQuery(
                "select nir from Beneficiaire where date_anonymisation is null and nir in (:nirs) "
                 )
            .setParameter("nirs", nirs)
            .getResultList();
    }


    @Override
    public List<Long> findIndividuRgpd(List<Long> ids) {
        return entityManager
            .createNativeQuery(
                "select a.id from individu a join BENEFICIAIRE c on c.nir = a.nir and c.id in (:ids) "
                    + " where a.nir not in ("
                    + "    select b.nir from BENEFICIAIRE b where b.nir = a.nir and b.id <> c.id and b.date_anonymisation is null "
                    + ")")
            .setParameter("ids", ids)
            .getResultList();
    }

    @Override
    public List<Long> findIndividuRgpdNyNir(List<String> nirs) {
        return entityManager
            .createNativeQuery(
                "select id from individu where nir in (:nirs) ")
            .setParameter("nirs", nirs)
            .getResultList();
    }

    @Override
    public int anonymiserBenefeciareNir(List<Long> ids) {
        return entityManager
            .createNativeQuery(
                "update BENEFICIAIRE set nir = null where  id in (:ids) and date_anonymisation is not null")
            .setParameter("ids", ids)
            .executeUpdate();
    }
    // ---------- UPDATES ----------

    @Override
    public int anonymisationHistoDonneesIndividu(List<Long> ids) {
        return entityManager
            .createNativeQuery(
                "UPDATE  HISTO_DONNEES_INDIVIDU SET NIR = NULL , NOM_FAMILLE = NULL, NOM_USAGE = NULL , PRENOMS = NULL,  "
                    + "DATE_NAISSANCE = NULL, LIEU_NAISSANCE = NULL,  DATE_CREATION = NULL, DEPARTEMENT_NAISSANCE = NULL , CODE_PAYS_NAISSANCE = NULL,CODE_SEXE = NULL  WHERE ID_INDIVIDU IN (:ids)")
            .setParameter("ids", ids)
            .executeUpdate();
    }


    @Override
    public int anonymisationIndividu(List<Long> ids) {
        return entityManager
            .createNativeQuery(
                "UPDATE INDIVIDU SET " +
                    "NIR = NULL, NOM_FAMILLE = NULL, NOM_USAGE = NULL, PRENOMS = NULL, " +
                    "DATE_NAISSANCE = NULL, LIEU_NAISSANCE = NULL, " +
                    "DEPARTEMENT_NAISSANCE = NULL, CODE_PAYS_NAISSANCE = NULL, " +
                    "CODE_SEXE = NULL, DATE_RECEPTION_TAUX = NULL " +
                    "WHERE ID IN (:ids)")
            .setParameter("ids", ids)
            .executeUpdate();
    }


    @Override
    public int anonymisationBeneficiaire(List<Long> ids, LocalDateTime dateAnonimisation) {
        return entityManager
            .createNativeQuery(
                "UPDATE BENEFICIAIRE SET " +
                    " NOM_FAMILLE = 'Xxxxx', NOM_USAGE = 'Xxxxx', PRENOMS = 'Xxxxx', " +
                    "ADRESSE = NULL, CODE_POSTAL = NULL, LOCALITE = NULL, " +
                    "CODE_DISTRI_ETR = NULL, COMPL_LOCALISATION = NULL, " +
                    "DATE_NAISSANCE = NULL, LIEU_NAISSANCE = NULL, NTT = NULL, " +
                    "DEPARTEMENT_NAISSANCE = NULL, CODE_PAYS_NAISSANCE = NULL, CODE_SEXE = NULL , DATE_ANONYMISATION = :dateAnonimisation"
                    +
                    " WHERE ID IN (:ids)")
            .setParameter("ids", ids)
            .setParameter("dateAnonimisation", dateAnonimisation)
            .executeUpdate();
    }

    @Override
    public int anonymisationHistoriqueBeneficiaire(List<Long> ids) {
        return entityManager
            .createNativeQuery(
                "UPDATE HISTO_BENEFICIAIRE SET " +
                    "NIR = NULL, NOM_FAMILLE = NULL, NOM_USAGE = NULL, PRENOMS = NULL, " +
                    "ADRESSE = NULL, CODE_POSTAL = NULL, LOCALITE = NULL, CODE_PAYS = NULL, " +
                    "SERV_DISTRI = NULL, CODE_DISTRI_ETR = NULL, COMPL_LOCALISATION = NULL, " +
                    "DATE_NAISSANCE = NULL, LIEU_NAISSANCE = NULL, NTT = NULL, " +
                    "DEPARTEMENT_NAISSANCE = NULL, CODE_PAYS_NAISSANCE = NULL, CODE_SEXE = NULL " +
                    "WHERE ID_BENEFICIAIRE IN (:ids)")
            .setParameter("ids", ids)
            .executeUpdate();
    }
}
