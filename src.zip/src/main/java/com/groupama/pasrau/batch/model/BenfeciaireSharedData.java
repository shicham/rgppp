package com.groupama.pasrau.batch.model;

import java.util.HashSet;
import java.util.Set;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.stereotype.Component;

@Component
@JobScope
public class BenfeciaireSharedData {

    private Set<BeneficiaireAAnonymiser> beneficiaireIds = new HashSet<>();

    public Set<BeneficiaireAAnonymiser> getBeneficiaireIds() {
        return beneficiaireIds;
    }

    public void setBeneficiaireIds(Set<BeneficiaireAAnonymiser> beneficiaireIds) {
        this.beneficiaireIds = beneficiaireIds;
    }
}
