package com.groupama.pasrau.batch.metier;

import com.groupama.pasrau.batch.model.BeneficiaireAAnonymiser;
import java.time.LocalDateTime;
import java.util.List;

public interface AnonymisationRepositoryCustom {
     List<BeneficiaireAAnonymiser> extractBeneficiaireAAnonymis(Integer moisRetentionCreation,
        Integer moisRetentionRegularisation, Integer moisRetentionVersement,
        Integer moisRetentionDeclaration);

    List<Long> findIndividuRgpd(List<Long> ids);
    List<Long> findIndividuRgpdNyNir(List<String> nirs);

    int anonymisationHistoDonneesIndividu(List<Long> ids);

    int anonymisationIndividu(List<Long> ids);

    int anonymisationBeneficiaire(List<Long> ids, LocalDateTime dateAnonimisation);

    int anonymisationHistoriqueBeneficiaire(List<Long> ids);

    public List<BeneficiaireAAnonymiser> findBenefAnonymise(LocalDateTime dateAnonym);

    public int anonymiserBenefeciareNir(List<Long> ids);

    public List<String> findNirElegible(List<String> nirs);

}
