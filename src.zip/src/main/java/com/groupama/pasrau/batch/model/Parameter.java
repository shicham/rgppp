package com.groupama.pasrau.batch.model;

import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name = "PARAMETRE")
public class Parameter {

    @GeneratedValue(
        strategy = GenerationType.SEQUENCE,
        generator = "idParameterGenerator"
    )
    @SequenceGenerator(
        name = "idParameterGenerator",
        sequenceName = "ID_PARAMETRE_SEQ",
        initialValue = 1,
        allocationSize = 1
    )
    @Id
    @Column(
        name = "ID",
        columnDefinition = "long default 0"
    )
    private Long id;
    @Column(name = "CODE", unique = true)
    private String code;
    @Column(name = "VALEUR")
    private String valeur;
    @Column(name = "DESCRIPTION")
    private String description;
    @Column(name = "TYPE")
    private String type;
    @Column(name = "SOUS_TYPE")
    private String sousType;
    public Parameter() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getValeur() {
        return valeur;
    }

    public void setValeur(String valeur) {
        this.valeur = valeur;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSousType() {
        return sousType;
    }

    public void setSousType(String sousType) {
        this.sousType = sousType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Parameter parameter = (Parameter) o;
        return id == parameter.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Parameter{" +
            "code='" + code + '\'' +
            ", valeur='" + valeur + '\'' +
            '}';
    }
}
