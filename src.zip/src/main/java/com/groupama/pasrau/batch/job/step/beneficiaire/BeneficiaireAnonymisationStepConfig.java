package com.groupama.pasrau.batch.job.step.beneficiaire;

import com.groupama.pasrau.batch.model.BeneficiaireAAnonymiser;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BeneficiaireAnonymisationStepConfig {

    /**
     * Configuration du step d'anonymisation des bénéficiaires.
     *
     * @param stepBuilderFactory le factory pour construire le step
     * @param beneficiaireAnonymisationStepReader le reader pour lire les bénéficiaires à anonymiser
     * @param beneficiaireAnonymisationStepWriter le writer pour écrire les bénéficiaires anonymisés
     * @param beneficiaireStepListener le listener pour suivre l'exécution du step
     * @return le step d'anonymisation des bénéficiaires
     */
    @Bean
    public Step beneficiaireAnonymisationStep(
        StepBuilderFactory stepBuilderFactory,
        ItemReader<BeneficiaireAAnonymiser> beneficiaireAnonymisationStepReader,
        ItemWriter<BeneficiaireAAnonymiser> beneficiaireAnonymisationStepWriter,
        StepExecutionListener beneficiaireStepListener) {

        return stepBuilderFactory.get("beneficiaireAnonymisationStep")
            .<BeneficiaireAAnonymiser, BeneficiaireAAnonymiser>chunk(1000)
            .reader(beneficiaireAnonymisationStepReader)
            .writer(beneficiaireAnonymisationStepWriter)
            .listener(beneficiaireStepListener)
            .build();
    }
}

