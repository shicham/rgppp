package com.groupama.pasrau.batch.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.SqlResultSetMapping;

@SqlResultSetMapping(
    name = "BeneficiaireAAnonymiserMapping",
    classes = @ConstructorResult(
        targetClass = BeneficiaireAAnonymiser.class,
        columns = {
            @ColumnResult(name = "idBeneficiaire", type = Long.class),
            @ColumnResult(name = "nir", type = String.class)
        }
    )
)
@Entity
public class BeneficiaireEntity  implements Serializable {
    private static final long serialVersionUID = 6904892166662722174L;
    @GeneratedValue(
        strategy = GenerationType.SEQUENCE,
        generator = "idBeneficiaireGenerator"
    )
    @SequenceGenerator(
        name = "idBeneficiaireGenerator",
        sequenceName = "ID_BENEFICIAIRE_SEQ",
        initialValue = 1,
        allocationSize = 1
    )
    @Id
    @Column(
        name = "ID",
        columnDefinition = "long default 0"
    )
    private Long id;
    @Column(
        name = "NIR",
        length = 13,
        nullable = true,
        unique = false
    )
    private String nir = "";
    public void setId(Long id) {
        this.id = id;
    }

    @Id
    public Long getId() {
        return id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        BeneficiaireEntity that = (BeneficiaireEntity) o;
        return id.equals(that.id) && Objects.equals(nir, that.nir);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "BeneficiaireEntity{" +
            "id=" + id +
            ", nir='" + nir + '\'' +
            '}';
    }
}
