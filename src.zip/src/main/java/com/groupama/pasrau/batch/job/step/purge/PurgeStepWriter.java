package com.groupama.pasrau.batch.job.step.purge;

import com.groupama.pasrau.batch.commun.utils.FileLineUtils;
import com.groupama.pasrau.batch.config.ApplicationRgpdConfig;
import com.groupama.pasrau.batch.utils.JobConstants;
import com.groupama.pasrau.batch.metier.PurgeRepositoryCustom;
import com.groupama.pasrau.batch.model.BeneficiaireAAnonymiser;
import com.groupama.pasrau.metier.domain.DeclarationRepository;
import java.io.File;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@StepScope
public class PurgeStepWriter implements ItemWriter<BeneficiaireAAnonymiser> {

    private static final Logger log = LoggerFactory.getLogger(PurgeStepWriter.class);

    private final PurgeRepositoryCustom purgeRepositoryCustom;
    private final DeclarationRepository declarationRepository;
    @Autowired
    private ApplicationRgpdConfig applicationRgpdConfig;
    @Value("#{jobExecutionContext['" + JobConstants.I_DATE_EXECUTION_JOB + "']}")
    private LocalDateTime dateExecutionJob;

    public PurgeStepWriter(PurgeRepositoryCustom purgeRepositoryCustom, DeclarationRepository declarationRepository) {
        this.purgeRepositoryCustom = purgeRepositoryCustom;
        this.declarationRepository = declarationRepository;
    }
   /**
     * Écrit les bénéficiaires à supprimer dans la base de données et met à jour le compte rendu technique.
     *
     * @param items la liste des bénéficiaires à supprimer
     */
    @Override
    public void write(List<? extends BeneficiaireAAnonymiser> items) {
        if (items == null || items.isEmpty()) {
            return;
        }
        String filePath = applicationRgpdConfig.getCheminFichierOutputCompteRenduTechnique(dateExecutionJob);
        File file = new File(filePath);

        List<Long> beneficiaireIds = items.stream()
            .map(BeneficiaireAAnonymiser::getIdBeneficiaire)
            .collect(Collectors.toList());

        FileLineUtils.processLine(file,String.format("  ✔ {} BENEFICIAIRE A SUPPRIMER IDS : %s",beneficiaireIds), true);
    /* ===============================
       1️⃣ Tables de liaison
       =============================== */

        int  deleteLienRegulBenefDeclarationByBeneficiaireIds = purgeRepositoryCustom.deleteLienRegulBenefDeclarationByBeneficiaireIds(beneficiaireIds);
        log.info("  ✔ {} deleteLienRegulBenefDeclarationByBeneficiaireIds", deleteLienRegulBenefDeclarationByBeneficiaireIds);
        FileLineUtils.processLine(file,String.format("  ✔ {} Suppression de LIEN_REGUL_BENEF_DECLARATION : %s",deleteLienRegulBenefDeclarationByBeneficiaireIds), true);

        int  deleteLienVersementDeclarationByBeneficiaireIds = purgeRepositoryCustom.deleteLienVersementDeclarationByBeneficiaireIds(beneficiaireIds);
        log.info("  ✔ {} deleteLienVersementDeclarationByBeneficiaireIds", deleteLienVersementDeclarationByBeneficiaireIds);
        FileLineUtils.processLine(file,String.format("  ✔ {} Suppression de LIEN_VERSEMENT_DECLARATION : %s",deleteLienVersementDeclarationByBeneficiaireIds), true);

        int  deleteContributionSocialeRegulVersementByBeneficiaireIds = purgeRepositoryCustom.deleteContributionSocialeRegulVersementByBeneficiaireIds(beneficiaireIds);
        log.info("  ✔ {} deleteContributionSocialeRegulVersementByBeneficiaireIds", deleteContributionSocialeRegulVersementByBeneficiaireIds);
        FileLineUtils.processLine(file,String.format("  ✔ {} Suppression de CONTRIBUTION_SOCIALE CODE_TYPE_PAIEMENT='RGUR' : %s",deleteContributionSocialeRegulVersementByBeneficiaireIds), true);

        int  deleteLienRegulVersDeclarationByBeneficiaireIds = purgeRepositoryCustom.deleteLienRegulVersDeclarationByBeneficiaireIds(beneficiaireIds);
        log.info("  ✔ {} deleteLienRegulVersDeclarationByBeneficiaireIds", deleteLienRegulVersDeclarationByBeneficiaireIds);
        FileLineUtils.processLine(file,String.format("  ✔ {} Suppression de LIEN_REGUL_VERS_DECLARATION : %s",deleteLienRegulVersDeclarationByBeneficiaireIds), true);
    /* ===============================
       2️⃣ Contribution sociale
       =============================== */


    /* ===============================
       3️⃣ Historiques bénéficiaire
       =============================== */

        int  deleteHistoTauxBeneficiaireByBeneficiaireIds = purgeRepositoryCustom.deleteHistoTauxBeneficiaireByBeneficiaireIds(beneficiaireIds);
        log.info("  ✔ {} deleteHistoTauxBeneficiaireByBeneficiaireIds", deleteHistoTauxBeneficiaireByBeneficiaireIds);
        FileLineUtils.processLine(file,String.format("  ✔ {} Suppression de HISTO_TAUX_BENEFICIAIRE : %s",deleteHistoTauxBeneficiaireByBeneficiaireIds), true);

        int  deleteHistoBeneficiaireByBeneficiaireIds = purgeRepositoryCustom.deleteHistoBeneficiaireByBeneficiaireIds(beneficiaireIds);
        log.info("  ✔ {} deleteHistoBeneficiaireByBeneficiaireIds", deleteHistoBeneficiaireByBeneficiaireIds);
        FileLineUtils.processLine(file,String.format("  ✔ {} Suppression de HISTO_BENEFICIAIRE : %s",deleteHistoBeneficiaireByBeneficiaireIds), true);

        int  deleteDeclarationAmorcageTauxByBeneficiaireIds = purgeRepositoryCustom.deleteDeclarationAmorcageTauxByBeneficiaireIds(beneficiaireIds);
        log.info("  ✔ {} deleteDeclarationAmorcageTauxByBeneficiaireIds", deleteDeclarationAmorcageTauxByBeneficiaireIds);
        FileLineUtils.processLine(file,String.format("  ✔ {} Suppression de DECLARATION_AMORCAGE_TAUX : %s",deleteDeclarationAmorcageTauxByBeneficiaireIds), true);

    /* ===============================
       4️⃣ Versements
       =============================== */

        int  deleteRegularisationVersementByBeneficiaireIds = purgeRepositoryCustom.deleteRegularisationVersementByBeneficiaireIds(beneficiaireIds);
        log.info("  ✔ {} deleteRegularisationVersementByBeneficiaireIds", deleteRegularisationVersementByBeneficiaireIds);
        FileLineUtils.processLine(file,String.format("  ✔ {} Suppression de REGULARISATION_VERSEMENT : %s",deleteRegularisationVersementByBeneficiaireIds), true);

        int  deleteContributionSocialeVersementByBeneficiaireIds = purgeRepositoryCustom.deleteContributionSocialeVersementByBeneficiaireIds(beneficiaireIds);
        log.info("  ✔ {} deleteContributionSocialeVersementByBeneficiaireIds", deleteContributionSocialeVersementByBeneficiaireIds);
        FileLineUtils.processLine(file,String.format("  ✔ {} Suppression de CONTRIBUTION_SOCIALE='REGL' : %s",deleteContributionSocialeVersementByBeneficiaireIds), true);

        int  deleteVersementByBeneficiaireIds = purgeRepositoryCustom.deleteVersementByBeneficiaireIds(beneficiaireIds);
        log.info("  ✔ {} deleteVersementByBeneficiaireIds", deleteVersementByBeneficiaireIds);
        FileLineUtils.processLine(file,String.format("  ✔ {} Suppression de VERSEMENT : %s",deleteVersementByBeneficiaireIds), true);

    /* ===============================
       5️⃣ Régularisation bénéficiaire
       =============================== */

        int  deleteContributionSocialeRegulBeneficiaireByBeneficiaireIds = purgeRepositoryCustom.deleteContributionSocialeRegulBeneficiaireByBeneficiaireIds(beneficiaireIds);
        log.info("  ✔ {} deleteContributionSocialeRegulBeneficiaireByBeneficiaireIds", deleteContributionSocialeRegulBeneficiaireByBeneficiaireIds);
        FileLineUtils.processLine(file,String.format("  ✔ {} Suppression de CONTRIBUTION_SOCIALE='RGUB' : %s",deleteContributionSocialeRegulBeneficiaireByBeneficiaireIds), true);

        int  deleteRegularisationBeneficiaireByBeneficiaireIds = purgeRepositoryCustom.deleteRegularisationBeneficiaireByBeneficiaireIds(beneficiaireIds);
        log.info("  ✔ {} deleteRegularisationBeneficiaireByBeneficiaireIds", deleteRegularisationBeneficiaireByBeneficiaireIds);
        FileLineUtils.processLine(file,String.format("  ✔ {} Suppression de REGULARISATION_BENEFICIAIRE : %s",deleteRegularisationBeneficiaireByBeneficiaireIds), true);

    /* ===============================
       6️⃣ Historiques individu
       =============================== */

        int  deleteHistoTauxIndividuByBeneficiaireIds = purgeRepositoryCustom.deleteHistoTauxIndividu();
        log.info("  ✔ {} deleteHistoTauxIndividuByBeneficiaireIds", deleteHistoTauxIndividuByBeneficiaireIds);
        FileLineUtils.processLine(file,String.format("  ✔ {} Suppression de HISTO_TAUX_INDIVIDU : %s",deleteHistoTauxIndividuByBeneficiaireIds), true);

        int  deleteHistoDonneesIndividuByBeneficiaireIds = purgeRepositoryCustom.deleteHistoDonneesIndividu();
        log.info("  ✔ {} deleteHistoDonneesIndividuByBeneficiaireIds", deleteHistoDonneesIndividuByBeneficiaireIds);
        FileLineUtils.processLine(file,String.format("  ✔ {} Suppression de HISTO_DONNEES_INDIVIDU : %s",deleteHistoDonneesIndividuByBeneficiaireIds), true);
    /* ===============================
       7️⃣ Individu (non partagé)
       =============================== */

        int  deleteIndividuIfNotSharedByBeneficiaireIds = purgeRepositoryCustom.deleteIndividu();
        log.info("  ✔ {} deleteIndividuIfNotSharedByBeneficiaireIds", deleteIndividuIfNotSharedByBeneficiaireIds);
        FileLineUtils.processLine(file,String.format("  ✔ {} Suppression de INDIVIDU : %s",deleteIndividuIfNotSharedByBeneficiaireIds), true);

        /* ===============================
       5️⃣ Declaration bénéficiaire
       =============================== */

        int  deleteLienBenefDeclarationByBeneficiaireIds = purgeRepositoryCustom.deleteLienBenefDeclarationByBeneficiaireIds(beneficiaireIds);
        log.info("  ✔ {} deleteLienBenefDeclarationByBeneficiaireIds", deleteLienBenefDeclarationByBeneficiaireIds);
        FileLineUtils.processLine(file,String.format("  ✔ {} Suppression de LIEN_BENEF_DECLARATION : %s",deleteLienBenefDeclarationByBeneficiaireIds), true);

         /* ===============================
       8️⃣ Suppression finale
       =============================== */

        int  deleteBeneficiaireByIds = purgeRepositoryCustom.deleteBeneficiaireByIds(beneficiaireIds);
        log.info("  ✔ {} deleteBeneficiaireByIds", deleteBeneficiaireByIds);
        FileLineUtils.processLine(file,String.format("  ✔ {} Suppression de BENEFICIAIRE : %s",deleteBeneficiaireByIds), true);

    }
}
