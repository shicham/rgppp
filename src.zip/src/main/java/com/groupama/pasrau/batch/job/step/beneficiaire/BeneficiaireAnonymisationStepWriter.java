package com.groupama.pasrau.batch.job.step.beneficiaire;

import com.groupama.pasrau.batch.commun.utils.FileLineUtils;
import com.groupama.pasrau.batch.config.ApplicationRgpdConfig;
import com.groupama.pasrau.batch.utils.JobConstants;
import com.groupama.pasrau.batch.metier.AnonymisationRepositoryCustom;
import com.groupama.pasrau.batch.model.BeneficiaireAAnonymiser;
import com.groupama.pasrau.batch.model.BenfeciaireSharedData;
import java.io.File;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@StepScope
public class BeneficiaireAnonymisationStepWriter
    implements ItemWriter<BeneficiaireAAnonymiser> {

    private static final Logger log = LoggerFactory.getLogger(BeneficiaireAnonymisationStepWriter.class);

    @Value("#{jobExecutionContext['" + JobConstants.DATE_ANONYMISATION_KEY + "']}")
    private LocalDateTime dateAnonimisation;
    @Autowired
    private AnonymisationRepositoryCustom anonymisationRepositoryCustom;
    @Autowired
    BenfeciaireSharedData benfeciaireSharedData;

    @Value("#{jobExecutionContext['" + JobConstants.I_DATE_EXECUTION_JOB + "']}")
    private LocalDateTime dateExecutionJob;

    @Autowired
    private ApplicationRgpdConfig applicationRgpdConfig;

   /**
     * Écrit les bénéficiaires à anonymiser dans la base de données et met à jour le compte rendu technique.
     *
     * @param items la liste des bénéficiaires à anonymiser
     */
    @Override
    public void write(List<? extends BeneficiaireAAnonymiser> items) {
        if (items == null || items.isEmpty()) {
            return;
        }

        List<Long> ids = items.stream()
            .map(BeneficiaireAAnonymiser::getIdBeneficiaire)
            .collect(Collectors.toList());

        benfeciaireSharedData.getBeneficiaireIds().addAll(items);
        log.info("✔ {} ids a anonymisés", ids.size());

        int historiqueBeneficiaireAnonymises = anonymisationRepositoryCustom.anonymisationHistoriqueBeneficiaire(ids);
        int beneficiaireAnonymises = anonymisationRepositoryCustom.anonymisationBeneficiaire(ids, dateAnonimisation);
        log.info(" |_______✔ {} bénéficiaires anonymisés", beneficiaireAnonymises);
        log.info("     |_______✔ {} historiqueBeneficiaire anonymisés", historiqueBeneficiaireAnonymises);

        writeTechnicalReport(ids, beneficiaireAnonymises,historiqueBeneficiaireAnonymises);

    }


    /**
     * Écrit un compte rendu technique dans un fichier de log avec les détails de l'anonymisation des bénéficiaires.
     *
     * @param ids                la liste des IDs des bénéficiaires anonymisés
     * @param beneficiaireCount  le nombre de bénéficiaires anonymisés
     * @param historiqueCount    le nombre d'historique bénéficiaire anonymisés
     */
    private void writeTechnicalReport(List<Long> ids, int beneficiaireCount, int historiqueCount) {
        try {
            String filePath = applicationRgpdConfig.getCheminFichierOutputCompteRenduTechnique(dateExecutionJob);
            File file = new File(filePath);
            FileLineUtils.processLine(file,String.format(" |_______✔ bénéficiaires anonymisés ids : {%s}",ids), true);
            FileLineUtils.processLine(file,String.format(" |_______✔ bénéficiaires anonymisés : {%s}",beneficiaireCount), true);
            FileLineUtils.processLine(file, String.format("     |_______✔  historiques bénéficiaires anonymisés : {%s}",historiqueCount), true);
        } catch (Exception e) {
            log.error("Erreur lors de l’écriture du compte rendu technique", e);
        }
    }
}
