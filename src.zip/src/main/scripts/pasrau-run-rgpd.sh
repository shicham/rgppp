#!/bin/ksh
#**************************************************************************
#  VERSION             : 202601
#  FICHIER             : pasrau-run-rgpd.sh
#  DESCRIPTON          :
#  		Script de lancement du batch rgpd anonymisation et de purge des données personnelles.
#  ARGUMENTS           :
#  AUTEUR              : GS4085
#  CREATION            : 18/02/2026
# --------------------------------------------------------------------------
#  MODIFICATIONS       :
#
#
#**************************************************************************
#---------------------------------------------
# PARAMETRAGE
#---------------------------------------------
# On appelle la config globale
. /app/shell/setenv.sh

# Chemin de l'executable java. Exemple: /app/ra1sflrrfn/java/jdk1.8.0_131
JAVA_PATH=${java_home}/bin/java

# Nom de la classe Java contenant la methode main() a executer
JAVA_CLASS=com.groupama.pasrau.batch.RgpdApplication

# Classpath pour execution du programme => ou sont les properties et ou sont les jar
JAVA_CP=/data/${env_host}/${app_code}/conf:/data/${env_host}/${app_code}/conf-db:/data/${env_host}/${app_code}/bin/*

# Options Java classiques
#JAVA_OPTS="-Xms1024m -Xmx3072m"
JAVA_OPTS="-XX:ParallelGCThreads=8 -XX:+CMSClassUnloadingEnabled -XX:InitiatingHeapOccupancyPercent=70 -XX:+UnlockDiagnosticVMOptions -XX:+UseConcMarkSweepGC -Xms3048m -Xmx6144m -XX:MaxMetaspaceSize=8192M -Dfile.encoding=UTF-8"
#---------------------------------------------
# EXECUTION
#---------------------------------------------

echo ""
echo "--------------- EXECUTION DE $0 ---------------"
echo ""

CMD_LINE="${JAVA_PATH} -classpath ${JAVA_CP} ${JAVA_OPTS} ${JAVA_CLASS} $1 $2"
echo "LIGNE DE COMMANDE=${CMD_LINE}"
# Exec java
${CMD_LINE}

# -- Affichage du code retour
CODE_RETOUR=$?

echo ""
echo "---------------  CODE RETOUR=${CODE_RETOUR} ---------------"
echo ""

# fin du programme
exit ${CODE_RETOUR}
